package com.springboot.AOP4Log;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aop4LogApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aop4LogApplication.class, args);
	}

}
