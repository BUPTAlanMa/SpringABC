package com.springboot.mapper;

import com.springboot.bean.User;
import com.springboot.config.MyMapper;

public interface UserMapper extends MyMapper<User> {
}